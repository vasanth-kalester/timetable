(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_1j1xvqs._.js","static/chunks/node_modules_16htjvv._.js"],
    source: "dynamic"
});
