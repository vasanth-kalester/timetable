(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0_zbhso._.css","static/chunks/node_modules_12dg6ay._.js","static/chunks/src_components_providers_NextAuthProvider_tsx_0ukh_qr._.js"],
    source: "dynamic"
});
