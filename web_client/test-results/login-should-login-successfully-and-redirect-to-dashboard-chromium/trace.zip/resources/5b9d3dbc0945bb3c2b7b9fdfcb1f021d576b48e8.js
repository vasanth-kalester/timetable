(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_1gf3vsr._.js","static/chunks/src_components_1onm-uj._.js"],
    source: "dynamic"
});
